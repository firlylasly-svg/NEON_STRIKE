NEON STRIKE: ARENA — Deluxe 2D browser shooter

PLAY
1. Extract this ZIP.
2. Open index.html in a modern browser.
3. Click OFFLINE OPS.
4. Move with WASD or arrow keys, aim with mouse, hold click to fire.
5. On touchscreens, use the on-screen movement pad and FIRE button.

FEATURES
- Polished neon arena graphics, grid, cover blocks, glow effects and hit particles
- Computer-controlled enemy bots that chase the player
- Stronger elite bots, escalating waves, health, score and eliminations
- Keyboard, mouse and basic touchscreen controls
- No libraries or install required; the game can run locally without internet

ONLINE MODE
The menu includes an Online Arena placeholder, but real multiplayer is NOT implemented in this build. To make it online, we need to add a multiplayer server/service, room creation/joining, and synchronization. Publishing this file alone does not create multiplayer.

FREE HOSTING
You can publish index.html with GitHub Pages:
1. Create a free GitHub account and a public repository.
2. Upload index.html to the repository root.
3. Go to Settings -> Pages.
4. Select Deploy from a branch, choose main and /(root), then Save.
